
SIMPLE WEB API (Node.js + Express)

Cara menjalankan:
1. Install Node.js
2. Buka terminal di folder project
3. Jalankan: npm install
4. Jalankan: npm start

Endpoint:
GET    /students
GET    /students/:id
POST   /students
DELETE /students/:id

Contoh POST body:
{
  "name": "Budi",
  "major": "Informatics"
}
