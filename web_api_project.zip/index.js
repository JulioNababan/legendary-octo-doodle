
const express = require('express');
const app = express();
app.use(express.json());

let students = [
  { id: 1, name: "Andi", major: "Informatics" },
  { id: 2, name: "Siti", major: "Information Systems" }
];

// GET all students
app.get('/students', (req, res) => {
  res.json(students);
});

// GET student by id
app.get('/students/:id', (req, res) => {
  const student = students.find(s => s.id == req.params.id);
  if (!student) return res.status(404).send("Student not found");
  res.json(student);
});

// POST add student
app.post('/students', (req, res) => {
  const newStudent = {
    id: students.length + 1,
    name: req.body.name,
    major: req.body.major
  };
  students.push(newStudent);
  res.json(newStudent);
});

// DELETE student
app.delete('/students/:id', (req, res) => {
  students = students.filter(s => s.id != req.params.id);
  res.send("Deleted");
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
